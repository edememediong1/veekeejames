export interface dataType {
    src : string,
    id: string,
    description : string,
    category: string
}

export const images : dataType[] = [
    {
       src: "https://veekeejames.com/wp-content/uploads/2023/12/IMG_1963-1.jpg",
       id: "1",
       description: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloremque consequuntur perspiciatis facere dolorem? Assumenda aliquam ducimus sed, fugit minima ipsa consequatur laboriosam maxime corrupti ipsam aspernatur natus exercitationem ex sequi sit nobis eaque quam ea earum iste veniam ut nulla. Natus id laboriosam ipsa dolorem vero autem temporibus modi facere.",
       category: "gowns"
    },
    {
        src: "https://veekeejames.com/wp-content/uploads/2023/12/IMG_1963-1.jpg",
        id: "2",
        description: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloremque consequuntur perspiciatis facere dolorem? Assumenda aliquam ducimus sed, fugit minima ipsa consequatur laboriosam maxime corrupti ipsam aspernatur natus exercitationem ex sequi sit nobis eaque quam ea earum iste veniam ut nulla. Natus id laboriosam ipsa dolorem vero autem temporibus modi facere.",
        category: "gowns"
     },
     {
        src: "https://veekeejames.com/wp-content/uploads/2023/12/IMG_1963-1.jpg",
        id: "3",
        description: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloremque consequuntur perspiciatis facere dolorem? Assumenda aliquam ducimus sed, fugit minima ipsa consequatur laboriosam maxime corrupti ipsam aspernatur natus exercitationem ex sequi sit nobis eaque quam ea earum iste veniam ut nulla. Natus id laboriosam ipsa dolorem vero autem temporibus modi facere.",
        category: "gowns"
     },
     {
        src: "https://veekeejames.com/wp-content/uploads/2023/12/IMG_1963-1.jpg",
        id: "4",
        description: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloremque consequuntur perspiciatis facere dolorem? Assumenda aliquam ducimus sed, fugit minima ipsa consequatur laboriosam maxime corrupti ipsam aspernatur natus exercitationem ex sequi sit nobis eaque quam ea earum iste veniam ut nulla. Natus id laboriosam ipsa dolorem vero autem temporibus modi facere.",
        category: "gowns"
     },
     {
        src: "https://veekeejames.com/wp-content/uploads/2023/12/IMG_1963-1.jpg",
        id: "5",
        description: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloremque consequuntur perspiciatis facere dolorem? Assumenda aliquam ducimus sed, fugit minima ipsa consequatur laboriosam maxime corrupti ipsam aspernatur natus exercitationem ex sequi sit nobis eaque quam ea earum iste veniam ut nulla. Natus id laboriosam ipsa dolorem vero autem temporibus modi facere.",
        category: "gowns"
     },
     {
        src: "https://veekeejames.com/wp-content/uploads/2023/12/IMG_1963-1.jpg",
        id: "6",
        description: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloremque consequuntur perspiciatis facere dolorem? Assumenda aliquam ducimus sed, fugit minima ipsa consequatur laboriosam maxime corrupti ipsam aspernatur natus exercitationem ex sequi sit nobis eaque quam ea earum iste veniam ut nulla. Natus id laboriosam ipsa dolorem vero autem temporibus modi facere.",
        category: "gowns"
     },
     {
        src: "https://veekeejames.com/wp-content/uploads/2023/12/IMG_1963-1.jpg",
        id: "7",
        description: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloremque consequuntur perspiciatis facere dolorem? Assumenda aliquam ducimus sed, fugit minima ipsa consequatur laboriosam maxime corrupti ipsam aspernatur natus exercitationem ex sequi sit nobis eaque quam ea earum iste veniam ut nulla. Natus id laboriosam ipsa dolorem vero autem temporibus modi facere.",
        category: "gowns"
     },
     {
        src: "https://veekeejames.com/wp-content/uploads/2023/12/IMG_1963-1.jpg",
        id: "8",
        description: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloremque consequuntur perspiciatis facere dolorem? Assumenda aliquam ducimus sed, fugit minima ipsa consequatur laboriosam maxime corrupti ipsam aspernatur natus exercitationem ex sequi sit nobis eaque quam ea earum iste veniam ut nulla. Natus id laboriosam ipsa dolorem vero autem temporibus modi facere.",
        category: "gowns"
     },
     {
        src: "https://veekeejames.com/wp-content/uploads/2023/12/IMG_1963-1.jpg",
        id: "9",
        description: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloremque consequuntur perspiciatis facere dolorem? Assumenda aliquam ducimus sed, fugit minima ipsa consequatur laboriosam maxime corrupti ipsam aspernatur natus exercitationem ex sequi sit nobis eaque quam ea earum iste veniam ut nulla. Natus id laboriosam ipsa dolorem vero autem temporibus modi facere.",
        category: "gowns"
     }

]
