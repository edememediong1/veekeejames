import React from 'react'

const NotFound = () => {
  return (
    <div>Page not found oooo</div>
  )
}

export default NotFound