import React from 'react'

const Loading = () => {
  return (
    <div>Page Loading</div>
  )
}

export default Loading